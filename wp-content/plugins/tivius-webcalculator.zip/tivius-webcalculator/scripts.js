$ = jQuery;
var ViewModel = function(){
	var self = this;
	self.suggestedProducts = ko.observableArray();

};
var viewModel = new ViewModel();
ko.applyBindings(viewModel, document.getElementById("results"));

$("#submit").click(function(){
	function validateEmail(email){
	    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	    return re.test(String(email).toLowerCase());
	}

	var name = $("#calc-name").val();
	var email = $("#calc-email").val();
	var emailValid = validateEmail(email);
	var tel = $("#calc-tel").val();
	var m2 = $("#calc-m2").val();
	var cm = $("#calc-cm").val();

	if(name && emailValid && tel && m2 && cm){
		$.ajax({
			url:'../wp-json/webcalc/v1/index',
			method:'POST',
			data:{
				name: name,
				email: email,
				tel: tel,
				metres: m2,
				cm: cm,
				isolation: $('#debelina').val()
			},
			success:function(res){
				viewModel.suggestedProducts.removeAll();
				res.forEach(function(element){
					viewModel.suggestedProducts.push(element);
				})
			},
			error:function(err){
				console.log(err.statusText);
			}
		})

	}else{
		alert("hello");
	}

});
